<?php

namespace App\Http\Controllers;

use App\Config;
use App\Email;
use App\EmailReader;
use Illuminate\Http\Request;

class EmailReaderController extends Controller
{
    //
    public function emailReader()
    {
        $reader = new EmailReader();

        $reader->readEmails();

        $url = $_SERVER['PHP_SELF'] . !empty($_GET) ? ('?' . http_build_query($_GET)) : '';
        $email_list = [];
        $max = (!Config::$maxEmails || Config::$maxEmails == -1) ? count($reader->emails) : Config::$maxEmails;

        if ($reader->emails) {
            rsort($reader->emails);
            foreach($reader->emails as $i => $email_number) {
                if ($reader->n === 0 || $max <= $i) break;

                $email = new Email($reader->con, $email_number);

                if (!$reader->querySearch || $email->matchSearch($reader->querySearch)) {
                    $reader->n--;
                    $email_list[] = $email;
                }
            }
        }

        return view('emailreader/emailreader', ['url' => $url, 'reader' => $reader, 'max' => $max, 'email_list' => $email_list]);
    }
}
